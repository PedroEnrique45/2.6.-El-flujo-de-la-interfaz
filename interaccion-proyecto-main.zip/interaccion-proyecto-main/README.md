# interaccion-proyecto
2.6. El flujo de la interfaz
